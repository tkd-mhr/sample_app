# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'f7e4e6d9107515644c58a39009b65ada063bb080439d63d386227f7202385c13ab2b5353bc6a221dd4f6708381bd5b7c25cd02bf647b9c67ee7e35768013e97e'
